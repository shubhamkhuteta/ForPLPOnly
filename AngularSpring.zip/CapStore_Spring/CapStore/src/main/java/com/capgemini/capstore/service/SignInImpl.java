package com.capgemini.capstore.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.capstore.beans.Admin;
import com.capgemini.capstore.beans.Customer;
import com.capgemini.capstore.beans.Merchant;
import com.capgemini.capstore.dao.IAdminDao;
import com.capgemini.capstore.dao.ICustomerDao;
import com.capgemini.capstore.dao.IMerchantDao;
import com.capgemini.capstore.util.Decryption;

@Service
public class SignInImpl implements ISignIn{
	
	@Autowired
	IAdminDao adminDao;

	@Autowired
	ICustomerDao customerDao;
	
	@Autowired
	IMerchantDao merchantDao;
	
	@Override
	public Admin findByAdminId(long adminId) throws Exception {

		Admin admin = adminDao.findByAdminId(adminId);
		admin.setAdminPassword(Decryption.decrypt(admin.getAdminPassword()));
		return admin;
	}
	
	@Override
	public Customer findByCustomerId(long customerId) {
		Customer customer = customerDao.findByCustomerId(customerId);
		customer.setCustomerPassword(Decryption.decrypt(customer.getCustomerPassword()));
		return customer;
	}
	
	@Override
	public Merchant findByMerchantId(long merchantId) {
		Merchant merchant = merchantDao.findByMerchantId(merchantId);
		merchant.setMerchantPassword(Decryption.decrypt(merchant.getMerchantPassword()));
		return merchant;
	}
}

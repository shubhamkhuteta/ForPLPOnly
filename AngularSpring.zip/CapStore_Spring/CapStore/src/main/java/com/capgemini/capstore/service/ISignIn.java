package com.capgemini.capstore.service;

import com.capgemini.capstore.beans.Admin;
import com.capgemini.capstore.beans.Customer;
import com.capgemini.capstore.beans.Merchant;

public interface ISignIn {
	
	Admin findByAdminId(long adminId) throws Exception;
	
	Customer findByCustomerId(long customerId);
	
	Merchant findByMerchantId(long merchantId);
}

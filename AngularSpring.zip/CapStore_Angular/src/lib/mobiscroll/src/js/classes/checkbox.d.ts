import { FormControl } from './form-control';
import { MbscFormOptions } from './forms';

export class CheckBox extends FormControl {
    constructor(element: any, settings: MbscFormOptions);
}
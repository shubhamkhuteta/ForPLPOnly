import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { MbscFormOptions } from 'src/lib/mobiscroll/src/js/classes/input.js';
import { mobiscroll} from 'src/lib/mobiscroll/js/mobiscroll.angular.min.js';



@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})

export class LoginComponent implements OnInit {


  constructor(private fb: FormBuilder) {
    this.loginForm = fb.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(6)]]
    });
  }

  loginForm: FormGroup;

  isLogin = false;
  attemptedSubmit = false;

  formSettings: MbscFormOptions = {
    lang: 'en',   // Specify language like: lang: 'pl' or omit setting to use default
    theme: 'ios-dark'  // Specify theme like: theme: 'ios' or omit setting to use default
  };

  errorMessages = {
    required: '{$1} required',
    minlength: 'At least 6 characters required',
    email: 'Invalid email address'
  };

  markFieldsDirty() {
    const controls = this.loginForm.controls;
    for (const field in controls) {
      if (controls[field]) {
        controls[field].markAsDirty();
      }
    }
  }

  signUp() {
    this.attemptedSubmit = true;
    if (this.loginForm.valid) {
      mobiscroll.toast({
        message: 'Signed Up!',
        callback: () => {
          this.loginForm.reset();
          this.attemptedSubmit = false;
        }
      });
    } else {
      this.markFieldsDirty();
    }
  }

  logIn() {
    this.attemptedSubmit = true;
    if (this.loginForm.valid) {
      mobiscroll.toast({
        message: 'Logged In!',
        callback: () => {
          this.loginForm.reset();
          this.attemptedSubmit = false;
        }
      });
    } else {
      this.markFieldsDirty();
    }
  }

  errorFor(fieldName: string) {
    const field = this.loginForm.controls[fieldName];
    for (const validator in field.errors) {
      if (field.errors[validator]) {
        const friendlyName = fieldName.charAt(0).toUpperCase() + fieldName.slice(1);
        return this.errorMessages[validator].replace('{$1}', friendlyName);
      }
    }
    return null;
  }

  ngOnInit() {
  }


}



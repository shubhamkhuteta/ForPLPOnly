import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthenticationService } from '../service/authentication.service';
import { LoginService } from '../service/login.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  username = ''
  password = ''
  invalidLogin = false
  login:LoginService;

  constructor(private router: Router,
    private loginservice: AuthenticationService,login:LoginService) {
      this.login=login;
     }

  ngOnInit() {
    // this.login.fetchAdmin();
    // this.login.fetchCustomer();
    // this.login.fetchMerchant();
  }

  checkLogin() {
    if (this.loginservice.authenticate(this.username, this.password)
    ) {
      this.router.navigate([''])
      this.invalidLogin = false
    } else{
      this.invalidLogin = true}

      // if(this.login.LoginAccount()){
      //   alert("Hurrraaaaaaaaaaaaaaaaaayyyyyyyyyyyyyyyyyyy")
      // }
  }

}
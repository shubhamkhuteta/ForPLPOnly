import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Admin } from '../beans/Admin';
import { Customer } from '../beans/Customer';
import { Merchant } from '../beans/Merchant';


@Injectable({
  providedIn: 'root'
})
export class LoginService {

  http:HttpClient;
  admins:Admin[]=[];
  customers:Customer[]=[];
  merchants:Merchant[]=[];

  constructor(http: HttpClient) {
    this.http = http;
    this.fetchAdmin();
    this.fetchCustomer();
    this.fetchMerchant();
    console.log(this.admins);
    console.log(this.customers);
    console.log(this.merchants);
  }

  fetchAdmin(){
    var admins = this.http.get('http://localhost:6798/admin/getAccounts')
    admins.subscribe((data)=>{
        this.convertAdmin(data);
    })
  }

  convertAdmin(data:any){
    for (let o of data) {
      let e = new Admin(o.adminId,o.adminName,o.adminPassword);
      this.admins.push(e);
    }
  }

  fetchCustomer(){
    var customers = this.http.get('http://localhost:6798/customer/getAccounts')
    customers.subscribe((data)=>{
        this.convertCustomer(data);
    })
  }

  convertCustomer(data:any){
    for (let o of data) {
      let e = new Customer(o.customerId ,o.customerName ,o.customerPassword,
        o.customerContactNo ,o.customerAddress ,o.customerStatus,
        o.customerQuestion, o.customerAnswer);
      this.customers.push(e);
    }
  }
  fetchMerchant(){
    var merchant = this.http.get('http://localhost:6798/merchant/getAccounts')
    merchant.subscribe((data)=>{
        this.convertMerchant(data);
    })
  }

  convertMerchant(data:any){
    for (let o of data) {
      let e = new Merchant(o.merchantId, o.merchantName, o.merchantPassword, 
        o.merchantContactNo, o.merchantGSTNo, o.merchantCompanyName, 
        o.merchantStatus, o.merchantDiscount, o.merchantQuestion, o.merchantAnswer);
      this.merchants.push(e);
    }
  }


  LoginAccount(){
    
  }
}

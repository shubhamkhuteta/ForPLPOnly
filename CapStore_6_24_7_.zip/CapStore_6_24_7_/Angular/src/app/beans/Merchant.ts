export class Merchant {

    merchantId: number;
    merchantName: string;
    merchantPassword: string;
    merchantContactNo: number;
    merchantGSTNo: string;
    merchantCompanyName: string;
    merchantStatus: string;
    merchantDiscount: number;
    merchantQuestion: number;
    merchantAnswer: string;

    constructor(merchantId: number, merchantName: string, merchantPassword: string, merchantContactNo: number, merchantGSTNo: string, merchantCompanyName: string, merchantStatus: string, merchantDiscount: number, merchantQuestion: number, merchantAnswer: string) {
        this.merchantId = merchantId;
        this.merchantName = merchantName;
        this.merchantPassword = merchantPassword;
        this.merchantContactNo = merchantContactNo;
        this.merchantGSTNo = merchantGSTNo;
        this.merchantCompanyName = merchantCompanyName;
        this.merchantStatus = merchantStatus;
        this.merchantDiscount = merchantDiscount;
        this.merchantQuestion = merchantQuestion;
        this.merchantAnswer = merchantAnswer;
    }
}


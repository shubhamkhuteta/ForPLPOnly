import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-register-merchant',
  templateUrl: './register-merchant.component.html',
  styleUrls: ['./register-merchant.component.css']
})
export class RegisterMerchantComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

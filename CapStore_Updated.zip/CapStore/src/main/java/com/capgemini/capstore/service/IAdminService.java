package com.capgemini.capstore.service;

import com.capgemini.capstore.beans.Admin;

public interface IAdminService {

	Admin createAccount(Admin admin) throws Exception;

	//List<AdminEntity> viewAllAdmin();

	Admin findByAdminId(long adminId) throws Exception;

}

package com.capgemini.capstore.service;

import java.security.NoSuchAlgorithmException;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.capstore.beans.Admin;
import com.capgemini.capstore.dao.IAdminDao;
import com.capgemini.capstore.util.EncryptionDecryptionAES;
import com.capgemini.capstore.util.Decryption;
import com.capgemini.capstore.util.Encryption;
@Service
public class AdminServiceImpl implements IAdminService {

	@Autowired
	IAdminDao adminDao;

	static Cipher cipher;  
	
	@Override
	public Admin createAccount(Admin admin) throws Exception {
		
		admin.setAdminPassword(Encryption.encrypt(admin.getAdminPassword()));
		adminDao.save(admin);
		return admin;
	}

	/*@Override
	public List<AdminEntity> viewAllAdmin() {
		return adminDao.findAll();
	}*/

	@Override
	public Admin findByAdminId(long adminId) throws Exception {
		
		Admin admin=  adminDao.findByAdminId(adminId);
		admin.setAdminPassword(Decryption.decrypt(admin.getAdminPassword()));
		return admin;
	}

}

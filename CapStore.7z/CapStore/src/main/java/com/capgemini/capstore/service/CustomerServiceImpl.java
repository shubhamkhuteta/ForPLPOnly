package com.capgemini.capstore.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.capstore.beans.Customer;
import com.capgemini.capstore.dao.ICustomerDao;

@Service
public class CustomerServiceImpl implements ICustomerService{
	
	@Autowired
	ICustomerDao customerDao;
	
	@Override
	public Customer createAccount(Customer customer) {
		customerDao.save(customer);
		return customerDao.findById(customer.getCustomerId()).get();
	}

	@Override
	public Customer viewById(long customerId) {
		return customerDao.findById(customerId).get();
	}
	
}

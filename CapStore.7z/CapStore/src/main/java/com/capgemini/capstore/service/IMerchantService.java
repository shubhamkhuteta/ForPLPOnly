package com.capgemini.capstore.service;

import com.capgemini.capstore.beans.Merchant;

public interface IMerchantService {

	Merchant createAccount(Merchant merchant);

	Merchant viewById(long merchantId);

}

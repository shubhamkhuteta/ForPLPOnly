package com.capgemini.capstore.service;

import com.capgemini.capstore.beans.Customer;

public interface ICustomerService {

	Customer createAccount(Customer customer);

	Customer viewById(long customerId);

}

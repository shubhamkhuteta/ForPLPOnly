package com.capgemini.capstore.service;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.capstore.beans.Admin;
import com.capgemini.capstore.dao.IAdminDao;
import com.capgemini.capstore.util.EncryptionDecryptionAES;

@Service
public class AdminServiceImpl implements IAdminService {

	@Autowired
	IAdminDao adminDao;

	static Cipher cipher;  
	
	@Override
	public Admin createAccount(Admin admin) throws Exception {
		KeyGenerator keyGenerator = KeyGenerator.getInstance("AES");
		keyGenerator.init(128); // block size is 128bits
		SecretKey secretKey = keyGenerator.generateKey();
		cipher = Cipher.getInstance("AES"); 
		
		admin.setAdminPassword(EncryptionDecryptionAES.encrypt(admin.getAdminPassword(), secretKey));
		adminDao.save(admin);
		return adminDao.findById(admin.getAdminId()).get();
	}

	/*@Override
	public List<AdminEntity> viewAllAdmin() {
		return adminDao.findAll();
	}*/

	@Override
	public Admin viewById(long adminId) {
		return adminDao.findById(adminId).get();
	}

}

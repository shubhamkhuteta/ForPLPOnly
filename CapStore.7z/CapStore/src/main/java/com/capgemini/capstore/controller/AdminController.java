package com.capgemini.capstore.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.capstore.beans.Admin;
import com.capgemini.capstore.service.IAdminService;

@RestController
@RequestMapping("/admin")
public class AdminController {
	@Autowired
	IAdminService adminService;
	
	@PostMapping(value="/create")
	public Admin createAccount(@RequestBody Admin admin) throws Exception
	{
		return adminService.createAccount(admin);
	}
	
	/*@GetMapping(value="/viewAll")
	public List<AdminEntity> viewAllAdmin()
	{
		return adminService.viewAllAdmin();	
	}*/
	
	@GetMapping(value="/view/{adminId}")
	public Admin viewById(@PathVariable long adminId)
	{
		return adminService.viewById(adminId);
	}
}

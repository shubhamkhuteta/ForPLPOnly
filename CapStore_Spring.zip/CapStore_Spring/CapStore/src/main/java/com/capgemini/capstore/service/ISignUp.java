package com.capgemini.capstore.service;

import com.capgemini.capstore.beans.Admin;
import com.capgemini.capstore.beans.Customer;
import com.capgemini.capstore.beans.Merchant;

public interface ISignUp {
	
	Admin createAccount(Admin admin) throws Exception;

	Customer createAccount(Customer customer);

	Merchant createAccount(Merchant merchant);
}

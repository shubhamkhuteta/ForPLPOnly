package com.capgemini.capstore.exceptions;

@SuppressWarnings("serial")
public class CapStoreException extends Exception {
	public CapStoreException() {
		super();
	}

	public CapStoreException(String msg) {
		super(msg);
	}

}
